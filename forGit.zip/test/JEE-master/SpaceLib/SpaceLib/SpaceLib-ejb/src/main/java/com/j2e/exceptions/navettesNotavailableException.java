
public class navettesNotavailableException extends Exception {

	public navettesNotavailableException(){
		
	}

    public navettesNotavailableException(String msg) {
        super(msg);
    }

}

