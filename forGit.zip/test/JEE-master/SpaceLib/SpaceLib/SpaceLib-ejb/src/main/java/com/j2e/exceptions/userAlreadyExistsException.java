
public class userAlreadyExistsException extends Exception{

	public userAlreadyExistsException(){
		
	}

public void userAlreadyExistsException(string msgError){
	super(msgError);
}
}
