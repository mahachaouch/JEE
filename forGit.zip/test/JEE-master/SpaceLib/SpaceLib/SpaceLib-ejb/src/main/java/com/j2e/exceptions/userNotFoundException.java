
public class userNotFoundException extends Exception{

	public userNotFoundException(){
		
	}

public void userNotFoundException(string msgError){
	super(msgError);
}
}
