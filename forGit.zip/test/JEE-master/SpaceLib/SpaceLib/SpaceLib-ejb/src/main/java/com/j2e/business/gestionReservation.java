@Stateless
public class gestionReservation implements gestionResaLocal{

}
