
public class quaisNotAvailableException extends Exception {

	public quaisNotAvailableException(){
		
	}

    public quaisNotAvailableException(String msg) {
        super(msg);
    }

}

